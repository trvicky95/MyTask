//
//  FavSpotListTVC.swift
//  FavouritePlacesSpot
//
//  Created by trioangle on 21/04/21.
//

import UIKit

class FavSpotListTVC: UITableViewCell, NibProtocol {

    @IBOutlet weak var mapBtn: UIButton!
    @IBOutlet weak var addressLbl: UILabel!
    @IBOutlet weak var cityLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.mapBtn.setTitle("View in map", for: .normal)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
