//
//  SearchTVC.swift
//  FavouritePlacesSpot
//
//  Created by trioangle on 21/04/21.
//

import UIKit

class SearchTVC: UITableViewCell,NibProtocol {
    @IBOutlet weak var locationImageView: UIImageView!
    
    @IBOutlet weak var subTitleLbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.locationImageView.image = UIImage(named: "ic_location")
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
