//
//  FavListDisplayVC.swift
//  FavouritePlacesSpot
//
//  Created by trioangle on 21/04/21.
//

import UIKit

protocol SelectFavSpotProtocol {
    func selectedFavSpotByProtocol(model:LocationModel)
}

class FavSpotListVC: UIViewController {
//    MARK:- IBOutlets
    @IBOutlet weak var listTableView: UITableView!
    
//    MARK:- Variables
    var favSpotList = [LocationModel]()
    var delegate:SelectFavSpotProtocol?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//    MARK:- Register Cells
        self.listTableView.register(FavSpotListTVC.nib, forCellReuseIdentifier: FavSpotListTVC.reuseId)
        self.listTableView.dataSource = self
        self.listTableView.delegate = self
//    MARK:- Get Saved Location Data
        self.getFavSpotList()
        // Do any additional setup after loading the view.
    }
    
    
    //    MARK:- InitWithStory to Get ViewController Object.
    class func intiWithStory(delegate:SelectFavSpotProtocol)->FavSpotListVC {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewController(withIdentifier: "FavSpotListVC") as! FavSpotListVC
        viewController.delegate = delegate
        return viewController
    }
    
//    MARK:- Get Saved Location Data
    func getFavSpotList() {
        CoreDataHandler.sharedInstance.fetchFavSpot { (response) in
            self.favSpotList = response
            if response.count > 0 {
                self.restoreTable()
            }else {
                self.emptyTableView(text: "No Data Found")
            }
            self.listTableView.reloadData()
        }
    }

    

}

//    MARK:- UITableView Delegate
extension FavSpotListVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
}

//    MARK:- UITableView DataSource
extension FavSpotListVC: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return favSpotList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: FavSpotListTVC.reuseId) as? FavSpotListTVC else {
            return UITableViewCell()
        }
        let model = favSpotList[indexPath.row]

        cell.addressLbl.text = model.address
        cell.cityLbl.text = model.city
        cell.mapBtn.addTarget(self, action: #selector(self.onClickedViewInMapAction(_:)), for: .touchUpInside)
        cell.mapBtn.tag = indexPath.row
        
        return cell
    }
    
    
//    MARK:- Button Click Action
    @objc func onClickedViewInMapAction(_ sender:UIButton) {
        let index = sender.tag
        self.delegate?.selectedFavSpotByProtocol(model: self.favSpotList[index])
        self.navigationController?.popViewController(animated: true)
    }
    
    
}


// MARK: TABLE BACKGROND UPDATE PROPERTIES
extension FavSpotListVC {
    
    func emptyTableView(text:String) {
        let result = UILabel(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: 100))
        result.text = text
        result.textAlignment = .center
        self.listTableView.backgroundView = result
    }
    
    func restoreTable() {
        self.listTableView.backgroundView = nil
    }

}
