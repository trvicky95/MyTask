//
//  ViewController.swift
//  FavouritePlacesSpot
//
//  Created by trioangle on 21/04/21.
//

import UIKit
import GoogleMaps

class MapViewController: UIViewController {
    
    // MARK:- IBOutlets
    
    @IBOutlet var searchTableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var mapView: GMSMapView!
    @IBOutlet weak var navToCurrentLocationBtn: UIButton!
    
    // MARK:- Variables
    var locationManager:CLLocationManager?
    var googleHandler: GoogleHandler?
    var lastSearchedText: String = ""
    
    var tableDataSource = [GoogleLocation]()
    var selectedMarker:GMSMarker?
    var currentLocationMarker:GMSMarker?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let rightBarBtn = UIBarButtonItem(title: "Show All", style: .plain, target: self, action: #selector(navigateToAllFavSpotList))
        self.navigationItem.rightBarButtonItem = rightBarBtn
        self.navigationItem.title = "Choose Your Spot"
        // MARK:- Handler for Google related datas.
        self.googleHandler = GoogleHandler()
        
        self.locationManager = CLLocationManager()
        self.locationManager?.delegate = self
        
        // MARK:- Set Delegates & DataSource for table view.
        self.searchTableView.dataSource = self
        self.searchTableView.delegate = self
        
        // MARK:- CHECK LOCATION PERMISSION AND TRIGGER LOCATION ALLOW POPUP.
        self.checkLocationPermission()
        
        self.searchBar.delegate = self
        self.searchBar.showsCancelButton = false
        
        //MARK:- REGISTER CELLS
        self.searchTableView.register(SearchTVC.nib, forCellReuseIdentifier: SearchTVC.reuseId)
        self.navToCurrentLocationBtn.addTarget(self, action: #selector(self.navigateToCurrentLocation), for: .touchUpInside)
        self.view.bringSubviewToFront(self.navToCurrentLocationBtn)
        self.navToCurrentLocationBtn.layer.borderWidth = 1
        self.navToCurrentLocationBtn.layer.borderColor = UIColor.black.cgColor
        self.navToCurrentLocationBtn.layer.cornerRadius = 10
        self.navToCurrentLocationBtn.backgroundColor = .white
        
    }
    
    // MARK:- Current Location Button Action.
    @objc  func navigateToCurrentLocation() {
        guard let marker = self.currentLocationMarker else {
            print("Location not initiated")
            self.checkLocationPermission()
            return
        }
        self.updateCurrentLocationMarker(coordinate: marker.position)
        self.mapView.selectedMarker = self.currentLocationMarker
        let camera = GMSCameraPosition.camera(withTarget: (marker.position), zoom: 14)
        self.mapView.animate(to: camera)
    }
    
    
    // MARK:- Show All List Action.
    @objc func navigateToAllFavSpotList() {
        let viewController = FavSpotListVC.intiWithStory(delegate: self)
        self.navigationController?.pushViewController(viewController, animated: true)
        
    }
    
    func startUpdatingCurrentLocation() {
        
        self.locationManager?.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager?.requestWhenInUseAuthorization()
        self.locationManager?.requestLocation()
        self.locationManager?.startUpdatingLocation()
    }

    func checkLocationPermission() {
        guard let locationManager = self.locationManager else {
            print("Location Manager not initialized")
            return
        }
        //MARK:- CEHCK LOCATION ENABLED OR NOT
        if CLLocationManager.locationServicesEnabled() {
            switch locationManager.authorizationStatus {
            
            case .notDetermined, .restricted, .denied :
                self.startUpdatingCurrentLocation()
            case .authorizedAlways, .authorizedWhenInUse:
                self.startUpdatingCurrentLocation()
            @unknown default:
                break
            }
            
        }
    }

}

//MARK:- LOCATION MANAGER DELEGATES
extension MapViewController :  CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations.first as Any)
        if let location = locations.first {
            let camera = GMSCameraUpdate.setTarget(location.coordinate)
            self.mapView.setMinZoom(10, maxZoom: 20)
            self.mapView.moveCamera(camera)
            self.updateCurrentLocationMarker(coordinate: location.coordinate)
        }
       
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error.localizedDescription)
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        print("authorization changed")
    }
}


//MARK:- UITABLE VIEW DELEGATES
extension MapViewController : UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
        self.googleHandler?.getDataFrom(placeID: self.tableDataSource[indexPath.row].placeID, completion: { (result) in
            switch result {
            case .success(let model):
                //MARK:- Store Selected Location in Core data
                CoreDataHandler.sharedInstance.storeFavSearch(model: model)
                
                self.updateLocationMarker(model: model)
                self.removeTableView()
            case .failure(let error):
                print("Ø \(error.localizedDescription)")
            }
        })
        
    }
    
    
}

//MARK:- UITABLE VIEW DATASOURCE
extension MapViewController :UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.tableDataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: SearchTVC.reuseId) as? SearchTVC else {
            return UITableViewCell()
        }
        let model = self.tableDataSource[indexPath.row]
        cell.titleLbl.text = model.title
        cell.subTitleLbl.text = model.subTitle
        return cell
    }
    
    
}

//MARK:- SEARCH BAR DELEGATES
extension MapViewController : UISearchBarDelegate {
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.showsCancelButton = false
        self.searchBar.resignFirstResponder()
        self.removeTableView()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        print("Search Button Clicked")
        self.searchBar.showsCancelButton = false
        self.searchBar.resignFirstResponder()
        self.onSearchActions()
        
    }
    
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {
        self.searchBar.showsCancelButton = true
        return true
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        print("textDidChange")
        self.onSearchActions()
    }
    
    
    //MARK:- Restrict to Search existing Data & Hit Search
    func onSearchActions() {
        
       print("Ø Search bar actions")
       let textFieldText = (self.searchBar.text ?? "").lowercased()
       if textFieldText.isEmpty {
           if !self.lastSearchedText.isEmpty {
               self.lastSearchedText = ""
//                remove all data
               
            self.removeTableView()
              
           }else {
               // Ideal same flow
             
               self.searchTableView.reloadData()
               
           }
       }
       else if textFieldText == self.lastSearchedText.lowercased() {
           // Ideal same flow
       }else {
           self.lastSearchedText = textFieldText
        self.wsToHitSearch(by: textFieldText)
       }
   }
    
    
    // MARK:- SERACH A TEXT
    func wsToHitSearch(by word:String) {
        self.googleHandler?.search(text: word, completion: { (result) in
            switch result {
            case .success(let results):
                self.tableDataSource = results
                self.addTableView()
                self.searchTableView.reloadData()
            case .failure(let error):
                print("Ø \(error.localizedDescription)")
            }
        })
    }
    
    
}


extension MapViewController {
    //MARK:- ADD TABLE VIEW AND REMOVE TABLE VIEW
    func addTableView() {
        if !self.view.subviews.contains(self.searchTableView) {
            self.searchTableView.frame = CGRect(x: 0, y: self.searchBar.frame.maxY + 10, width: self.searchBar.frame.width, height: 340)
            self.view.addSubview(self.searchTableView)
            self.view.bringSubviewToFront(self.searchTableView)
        }
    }
    
    func removeTableView() {
        self.searchBar.showsCancelButton = false
        self.searchBar.text = ""
        self.lastSearchedText = ""
        self.searchBar.resignFirstResponder()
        self.tableDataSource.removeAll()
        self.searchTableView.removeFromSuperview()
    }
    
    //MARK:- CURRENT LOCATION MARKER
    func updateCurrentLocationMarker(coordinate:CLLocationCoordinate2D) {
        let marker = GMSMarker()
        marker.position = coordinate
        marker.icon = UIImage(named: "ic_current_location")
        marker.map = self.mapView
        
        self.currentLocationMarker = marker
       
    }
    
    //MARK:- Move Camera and add new Marker
    func updateLocationMarker(model:LocationModel) {
        self.mapView.clear()
        
        let moveCameraPosition = GMSCameraPosition.camera(withTarget: CLLocationCoordinate2D(latitude: model.latitude, longitude: model.longitude), zoom: 14)
        self.mapView.animate(to: moveCameraPosition)
        self.selectedMarker = nil
        self.selectedMarker = GMSMarker(position: moveCameraPosition.target)
        self.selectedMarker?.icon = UIImage(named: "ic_location")
        self.selectedMarker?.map = self.mapView
        self.selectedMarker?.isFlat = true
        self.selectedMarker?.title = model.city
        if let location = self.currentLocationMarker {
            self.updateCurrentLocationMarker(coordinate: location.position)
        }
        self.mapView.selectedMarker = selectedMarker
    }

}

//MARK:- SelectFavSpotProtocol Action.
extension MapViewController : SelectFavSpotProtocol {
    func selectedFavSpotByProtocol(model: LocationModel) {
        self.updateLocationMarker(model: model)
    }
    
    
}



