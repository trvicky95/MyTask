//
//  NibProtocol.swift
//  FavouritePlacesSpot
//
//  Created by trioangle on 21/04/21.
//

import Foundation
import UIKit


protocol NibProtocol: class {
    static var nib: UINib { get }
    static var reuseId: String { get }
}

extension NibProtocol where Self: UIView {
    static var nib: UINib {
        return UINib(nibName: String(describing: self), bundle: nil)
            
    }
    
    static var reuseId: String {
        return String(describing: self)
    }
}
