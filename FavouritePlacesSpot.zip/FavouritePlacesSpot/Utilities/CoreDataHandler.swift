//
//  CoreDataHandler.swift
//  FavouritePlacesSpot
//
//  Created by trioangle on 21/04/21.
//

import UIKit
import CoreData

class CoreDataHandler: NSObject {
    static let sharedInstance = CoreDataHandler()
    // MARK: CORE DATA TABLE NAME
    let tableEntityName = "GoogleSearch"
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    private lazy var  managedContext:NSManagedObjectContext = {
        return self.appDelegate.persistentContainer.viewContext
    }()
    
    private lazy var coreTableEntity:NSEntityDescription =  {
       return NSEntityDescription.entity(forEntityName: tableEntityName,
                                         in: managedContext)!
    }()
    
    
    
    // MARK: STORE LOCATION IN CORE DATA
    func storeFavSearch(model:LocationModel) {
        let coreModel = NSManagedObject(entity: self.coreTableEntity,
                                    insertInto: self.managedContext)
        coreModel.setValue(model.address, forKey: "address")
        coreModel.setValue(model.city, forKey: "city")
        coreModel.setValue(model.country, forKey: "country")
        coreModel.setValue(model.latitude, forKey: "latitude")
        coreModel.setValue(model.longitude, forKey: "longitude")
        coreModel.setValue(model.postalCode, forKey: "postal_code")
        coreModel.setValue(model.state, forKey: "state")
        // MARK: CHECK EXISTING LOCATION
        if !isAlreadyAddedFavSpot(model: model) {
            self.saveEntity(coreModel)
        }
        
        
    }
    
    
    // MARK: CHECK EXISTING LOCATION
    func isAlreadyAddedFavSpot(model:LocationModel) -> Bool {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: tableEntityName)
        fetchRequest.predicate = NSPredicate(format: "(latitude = %@ AND longitude = %@)", model.latitude, model.longitude)
        do {
            let res = try managedContext.fetch(fetchRequest)
            return res.count > 0
        }
        catch(let error) {
            print("Ø \(error.localizedDescription)")
        }
      
        return false
    }
    
    // MARK: GET ALL SAVED LOCATION FROM CORE DATA
    func fetchFavSpot(completion:  @escaping ([LocationModel])->Void ) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: tableEntityName)
        do {
            let response = try managedContext.fetch(fetchRequest) as? [GoogleSearch]
            var locationModels = [LocationModel]()
            if let googleSearchs = response {
                googleSearchs.forEach { (model) in
                    let locationModel = LocationModel()
                    locationModel.address = model.address ?? ""
                    locationModel.latitude = model.latitude
                    locationModel.longitude = model.longitude
                    locationModel.country = model.country ?? ""
                    locationModel.state = model.state ?? ""
                    locationModel.postalCode = model.postal_code ?? ""
                    locationModel.city = model.city ?? ""
                    locationModels.append(locationModel)
                }
                
            }
            completion(locationModels)
        }
        catch(let error) {
            print("Ø \(error.localizedDescription)")
        }
    }
    
    
    // MARK: SAVE CORE DATA ENTITTY
    private func saveEntity(_ object : NSManagedObject){
      
        do{
            try object.managedObjectContext?.save()
        }catch{
            print("Core data save failed for entity : \(object.description)")
        }
    }
}
