//
//  GoogleHandler.swift
//  FavouritePlacesSpot
//
//  Created by trioangle on 21/04/21.
//

import UIKit
import CoreLocation
import GoogleMaps
import GooglePlaces

// MARK: CUSTOM ERROR ENUM
enum FavSpotError : Error{
    case failure(_ reason : String)
}

// MARK: CUSTOM HANDLERS ALIAS
typealias GoogleCompletion = (Result<LocationModel, FavSpotError>) ->Void
typealias GoogleSearchHandler = (Result<[GoogleLocation], FavSpotError>) ->Void




class GoogleHandler: NSObject {
    
    let geoCoder:GMSGeocoder
    override init() {
        self.geoCoder = GMSGeocoder()
    }
    
    // MARK: SEARCH BY PLACE ID USING GOOGLEPLACES SDK
    func getDataFrom(placeID id: String, completion: @escaping GoogleCompletion) {
        let placeClient = GMSPlacesClient()
        placeClient.lookUpPlaceID(id) { (place, error) in
            if let place = place {
                let locationModel = LocationModel()
                if let address = place.formattedAddress {
                    locationModel.address = address
                }
                locationModel.latitude = place.coordinate.latitude
                locationModel.longitude = place.coordinate.longitude
                //MARK: GET ADDRESS FROM ADDRESS COMPONENTS
                if let components = place.addressComponents {
                    for component in components {
                        if let result = component.types.first  {
                            if result == "locality" || result == "administrative_area_level_2" {
                                locationModel.city = component.name
                            }
            
                            else if result == "administrative_area_level_1" {
                                locationModel.state = component.name
                            }
                            else if result == "sublocality_level_1" {
                                locationModel.country  = component.name
                            }
                            else if result == "postal_code" {
                                locationModel.postalCode = component.name
                            }
                        }
                    }
                }
               
               
                completion(.success(locationModel))
            }
            else if let error = error {
                completion(.failure(FavSpotError.failure(error.localizedDescription)))
            }
        }
    }
    
    // MARK: SEARCH BY TEXT USING GOOGLEPLACES SDK
    func search(text location:String, completion: @escaping GoogleSearchHandler) {
        let placeClient = GMSPlacesClient()
        let filter = GMSAutocompleteFilter()
        filter.type = .noFilter
        placeClient.findAutocompletePredictions(fromQuery: location, filter: filter, sessionToken: GMSAutocompleteSessionToken()) { (predicitions, erro) in
            if let addressList = predicitions {
                print(addressList)
                var googleLocations = [GoogleLocation]()
                addressList.forEach { (model) in
                    let googleModel = GoogleLocation(title: model.attributedPrimaryText.string, subTitle: model.attributedSecondaryText?.string ?? "", placeID: model.placeID)
                    googleLocations.append(googleModel)
                }
                completion(.success(googleLocations))
            }
            else if let error = erro {
                print(error.localizedDescription)
                completion(.failure(FavSpotError.failure(error.localizedDescription)))
            }
        }
    }
}



