//
//  LocationModel.swift
//  FavouritePlacesSpot
//
//  Created by trioangle on 21/04/21.
//

import UIKit

class LocationModel: NSObject {
    var latitude:Double = 0.0
    var longitude:Double = 0.0
    var postalCode:String = ""
    var city:String = ""
    var state:String = ""
    var country:String = ""
    var address:String = ""
}


struct GoogleLocation{
    var title:String
    var subTitle:String
    var placeID:String
}
